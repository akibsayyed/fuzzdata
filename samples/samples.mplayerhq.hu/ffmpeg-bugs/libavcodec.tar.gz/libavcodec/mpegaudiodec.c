/* TODO, maybe use libmpg123, but this is less fun than rewriting it :-) */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "avcodec.h"

static int decode_init(AVCodecContext *s)
{
    return 0;
}

static int decode_frame(AVCodecContext *avctx, 
                        void *data, int *data_size,
                        UINT8 *buf, int buf_size)
{
    return -1;
}

AVCodec mp3_decoder = {
    "mp3",
    CODEC_TYPE_AUDIO,
    CODEC_ID_MP2,
    0,
    decode_init,
    NULL,
    NULL,
    decode_frame,
};
